package com.example.filesplitter

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        AppRoot()
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------
// الهيكل العام
// ------------------------------------------------------------------

@Composable
fun AppRoot() {
    var tab by remember { mutableIntStateOf(0) }
    val icons = listOf("✂", "🔗", "📄")
    val labels = listOf("تقسيم", "دمج", "PDF")

    Scaffold(
        bottomBar = {
            NavigationBar {
                for (i in labels.indices) {
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Text(icons[i]) },
                        label = { Text(labels[i]) }
                    )
                }
            }
        }
    ) { pad ->
        Box(modifier = Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> SplitScreen()
                1 -> MergeScreen()
                else -> PdfScreen()
            }
        }
    }
}

@Composable
private fun ScreenColumn(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(title, style = MaterialTheme.typography.headlineSmall)
        content()
    }
}

@Composable
private fun Choice(selected: Boolean, label: String, onClick: () -> Unit) {
    if (selected) {
        Button(onClick = onClick) { Text(label) }
    } else {
        OutlinedButton(onClick = onClick) { Text(label) }
    }
}

@Composable
private fun StatusArea(busy: Boolean, progress: Float, msg: String?) {
    if (busy) {
        LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
    }
    if (msg != null) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Text(msg, modifier = Modifier.padding(12.dp))
        }
    }
}

private fun launchTask(
    scope: CoroutineScope,
    setBusy: (Boolean) -> Unit,
    setMsg: (String?) -> Unit,
    work: () -> String
) {
    scope.launch {
        setBusy(true)
        setMsg(null)
        val result = try {
            withContext(Dispatchers.IO) { work() }
        } catch (t: Throwable) {
            "خطأ: " + (t.message ?: t.javaClass.simpleName)
        }
        setMsg(result)
        setBusy(false)
    }
}

private const val OUT_HINT = "Downloads/FileSplitter"

// ------------------------------------------------------------------
// تبويب 1: تقسيم أي ملف
// ------------------------------------------------------------------

@Composable
fun SplitScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var uri by remember { mutableStateOf<Uri?>(null) }
    var name by remember { mutableStateOf("") }
    var size by remember { mutableLongStateOf(0L) }
    var byParts by remember { mutableStateOf(true) }
    var value by remember { mutableStateOf("2") }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var msg by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            uri = u
            name = FileOps.displayName(ctx, u)
            size = FileOps.size(ctx, u)
            msg = null
        }
    }

    ScreenColumn("تقسيم أي ملف") {
        Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("اختيار ملف") }
        if (uri != null) {
            Text(name + "  •  " + FileOps.human(size))
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Choice(byParts, "حسب عدد الأجزاء") { byParts = true; value = "2" }
            Choice(!byParts, "حسب الحجم") { byParts = false; value = "10" }
        }

        OutlinedTextField(
            value = value,
            onValueChange = { v -> value = v.filter { it.isDigit() }.take(9) },
            label = { Text(if (byParts) "عدد الأجزاء" else "حجم الجزء (ميجابايت)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            enabled = uri != null && !busy && value.isNotEmpty(),
            onClick = {
                val u = uri
                val v = value.toLongOrNull()
                if (u != null && v != null) {
                    progress = 0f
                    launchTask(scope, { busy = it }, { msg = it }) {
                        val n = FileOps.splitFile(ctx, u, byParts, v) { p -> progress = p }
                        "تم! اتعمل $n جزء في $OUT_HINT"
                    }
                }
            }
        ) { Text("ابدأ التقسيم") }

        StatusArea(busy, progress, msg)
    }
}

// ------------------------------------------------------------------
// تبويب 2: دمج الأجزاء
// ------------------------------------------------------------------

@Composable
fun MergeScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var uris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var names by remember { mutableStateOf<List<String>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var msg by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { list ->
        if (list.isNotEmpty()) {
            uris = list
            names = list.map { FileOps.displayName(ctx, it) }.sortedBy { it.lowercase() }
            msg = null
        }
    }

    ScreenColumn("دمج أجزاء في ملف واحد") {
        Text("اختار كل الأجزاء (part001 و part002 ...) وهيتم ترتيبها تلقائيًا بالاسم.")
        Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("اختيار الأجزاء") }

        if (names.isNotEmpty()) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("الترتيب (" + names.size + " ملف):")
                    names.forEachIndexed { i, n -> Text((i + 1).toString() + ". " + n) }
                }
            }
        }

        Button(
            enabled = uris.size >= 2 && !busy,
            onClick = {
                val list = uris
                progress = 0f
                launchTask(scope, { busy = it }, { msg = it }) {
                    val out = FileOps.mergeFiles(ctx, list) { p -> progress = p }
                    "تم الدمج! الملف: $out في $OUT_HINT"
                }
            }
        ) { Text("ابدأ الدمج") }

        StatusArea(busy, progress, msg)
    }
}

// ------------------------------------------------------------------
// تبويب 3: تقسيم PDF
// ------------------------------------------------------------------

@Composable
fun PdfScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var uri by remember { mutableStateOf<Uri?>(null) }
    var name by remember { mutableStateOf("") }
    var pages by remember { mutableIntStateOf(0) }
    var eachPage by remember { mutableStateOf(false) }
    var spec by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var msg by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            uri = u
            name = FileOps.displayName(ctx, u)
            pages = 0
            msg = null
            launchTask(scope, { busy = it }, { m -> if (m != null && m.startsWith("خطأ")) msg = m }) {
                pages = FileOps.pdfPageCount(ctx, u)
                ""
            }
        }
    }

    ScreenColumn("تقسيم ملف PDF") {
        Button(onClick = { picker.launch(arrayOf("application/pdf")) }) { Text("اختيار ملف PDF") }
        if (uri != null) {
            Text(name + if (pages > 0) "  •  $pages صفحة" else "")
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Choice(!eachPage, "نطاقات صفحات") { eachPage = false }
            Choice(eachPage, "كل صفحة ملف") { eachPage = true }
        }

        if (!eachPage) {
            OutlinedTextField(
                value = spec,
                onValueChange = { spec = it },
                label = { Text("الصفحات") },
                placeholder = { Text("مثال: 1-3,5,7-9") },
                supportingText = { Text("كل نطاق بيطلع في ملف PDF منفصل") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }

        Button(
            enabled = uri != null && pages > 0 && !busy && (eachPage || spec.isNotBlank()),
            onClick = {
                val u = uri
                if (u != null) {
                    progress = 0f
                    val each = eachPage
                    val s = spec
                    launchTask(scope, { busy = it }, { msg = it }) {
                        val n = FileOps.splitPdf(ctx, u, each, s) { p -> progress = p }
                        "تم! اتعمل $n ملف PDF في $OUT_HINT"
                    }
                }
            }
        ) { Text("ابدأ تقسيم الـ PDF") }

        StatusArea(busy, progress, msg)
    }
}
